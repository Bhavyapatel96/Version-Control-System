secondtext changed to new toext
