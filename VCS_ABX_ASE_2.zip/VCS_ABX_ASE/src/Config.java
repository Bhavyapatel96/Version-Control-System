/*

*This class will hold the values required to configure the application.
* Contact Info :
*       Amit Joshi - amits2194@gmail.com
*       Bhavya Patel - bhavyaspatel@gmail.com
**/


public class Config {


    public static final double VERSION = 0.4;


    public static final String cmdCREATE="CREATE";
    public static final String cmdLABEL = "LABEL";
    public static final String cmdCHECKOUT = "CHECKOUT";
    public static final String cmdCHECKIN = "CHECKIN";



    //manifest file properties

    public static final String prpLABEL = "LABEL";


}
