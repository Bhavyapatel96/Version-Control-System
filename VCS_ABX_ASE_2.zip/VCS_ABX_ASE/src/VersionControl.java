/*
* This is the main calling function
* we check the command line arguemnts entered by the user and call the repo methods respectively
* Contact Info :
*       Amit Joshi - amits2194@gmail.com
*       Bhavya Patel - bhavyaspatel@gmail.com
**/


import java.io.File;

public class VersionControl {



    public static void main(String[] args){







            try{

                //send the command to the repo
                new Repo(args);



            }

            catch (Exception ex){


                System.out.println("Something went wrong.");
                System.out.println("Exception:"+ex.toString());

            }



        }




}
