/*
* Repo Class will do all the methods relating to the creation.
* We also add the methods to generate artifactID and create the respective manifest file for each command.
*
* Contact Info :
*       Amit Joshi - amits2194@gmail.com
*       Bhavya Patel - bhavyaspatel@gmail.com
**/


import java.io.*;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class Repo {


    private String targetPath;
    private String sourcePath;
    private static StringBuilder manifestBuilder;



    public Repo(String[] _args) throws IOException{

        String _cmd = _args[0];

        manifestBuilder  = new StringBuilder();


        switch (_cmd.toUpperCase()){


            case Config.cmdCREATE:
                initManifest(_cmd,"");

                targetPath = _args[2];
                sourcePath = _args[1];
                System.out.println("Creating new Repo...");


                createRepo();
                dumpManifest(targetPath,_cmd);



                System.out.println("Repo created.");

                break;

            case Config.cmdLABEL:
                addLabelToManifest(_args[2],_args[1],_args[3]);


                break;



            case Config.cmdCHECKOUT:

                initManifest(_cmd,"");
                sourcePath = _args[2];
                targetPath = _args[3];
                checkoutRepo(_args[1],sourcePath,targetPath);

                break;

            case Config.cmdCHECKIN:

                initManifest(_cmd,"");
                sourcePath = _args[1];
                targetPath = _args[2];
                checkinRepo(sourcePath,targetPath);
                dumpManifest(targetPath,_cmd);
                break;

            default:

                System.out.println("VCS help : ");
                System.out.println("Usage : VCS_ABX_ASE.jar <target_folder> <destination_folder>");
                System.out.println("VCS control system : CECS 543 Project (v" + Config.VERSION + ")");
                break;


        }




    }

    private void createRepo() throws IOException{


        File[] sourceFiles = new File(sourcePath).listFiles();


       //Create the file Structure

        //Create the parent repo folder inside the directory
        new File(targetPath).mkdirs();

        //copy the file structure from source to the repo
        copyFiles(sourceFiles,targetPath);




    }

private void checkinRepo(String sourcePath, String targetPath) throws IOException{


        File[] sourceFiles = new File(sourcePath).listFiles();

        //copy the file structure from source to the repo
        copyFiles(sourceFiles,targetPath);



    }



    private final void checkoutRepo(String sourcePath,String repoPath, String targetPath) throws IOException{

        //Steps to be done to checkout
        //copy the original project file structure
    File[] sourceFiles = null;
    File manifestFile = getManifest(repoPath, sourcePath);
        String projectFolder = null;
        if (manifestFile == null){
            System.out.println("Error getting the manifest file : "+sourcePath);
            return;
        }

        File parentFolder = manifestFile.getParentFile();

        for(File file:parentFolder.listFiles()){

            if(file.isDirectory()){
                projectFolder = file.getName();
                sourceFiles = file.listFiles();
                break;
            }
        }



        new File(targetPath +  "/"+ projectFolder).mkdirs();
    String targetOriginal = targetPath;
    targetPath = targetPath + "/" + projectFolder;


        generateOriginalFileStructure(sourceFiles,targetPath);

        //copy the respective files using artID from the manifest


        Scanner fileScanner = new Scanner(manifestFile);

        while(fileScanner.hasNextLine()) {

            String line = fileScanner.nextLine();

            if(line.toUpperCase().startsWith("FILENAME") ) {            //Manfiest with a matching label found

                String filename = line.split(":", 2)[1].trim();

                line = fileScanner.nextLine();


                String filepath = line.split(":", 2)[1].trim();

                line = fileScanner.nextLine();

                String artid = line.split(":", 2)[1].trim();

                //construct the path to be copied

                String filetobecopied = parentFolder + "/" + filepath + "/" + artid;

                File fileFromRepo = new File(filetobecopied);

                Files.copy(fileFromRepo.toPath(), (new File(targetOriginal+"/"+filepath ).toPath()));


            }

        }

    manifestBuilder.append("MANIFEST ID   :" + sourcePath );
    dumpManifest(parentFolder.getName(),Config.cmdCHECKOUT );

}


    private final void addLabelToManifest(String fileID, String repoPath, String newLabel) throws IOException{


        //todo: Only allow 4 labels for any given manifest

        File manifestFile = getManifest(repoPath,fileID);
        if (manifestFile == null){

            System.out.println("Error adding new label to the manifest.. Please check the path or label entered.");
        }

        FileWriter fw = new FileWriter(repoPath + "/"  + manifestFile.getName(),true); //the true will append the new data
        fw.write("LABEL     :"+newLabel +System.getProperty("line.separator"));//appends the string to the file
        fw.close();




    }




    private void copyFiles(File[] files,String target) throws IOException {

        for (File file : files) {


            if (file.isDirectory()) {


                new File(target + "/" + file.getPath()).mkdirs();
                copyFiles(file.listFiles(), target);

            } else {                //This is a file needs to be added to repo


                String destinationPath;
                String artID;
                destinationPath = target + "/" + file.getPath();
                new File(destinationPath).mkdirs();
                artID = getCheckSum(file.getPath());

                String extension = getExtension(file.getName());
                String newFileName = artID+"."+extension;



                if (!new File(destinationPath + "/" + newFileName).exists())
                Files.copy(file.toPath(), (new File(destinationPath + "/" + newFileName).toPath()));

                addFileToManifest(file.getName(), newFileName, file.getPath());


            }
        }
    }



    private void generateOriginalFileStructure(File[] files,String target) {

        //iterate through the entire structure
        //don't copy files which don't have a 'File' inside it


        for (File file : files) {


            if (file.isDirectory()) {



                if (file.listFiles().length > 0) {

                    boolean isFolder = false;

                    for(File subFile:file.listFiles()){

                        if (subFile.isFile()){
                            break;
                        }

                        else
                        {
                            isFolder = true;
                            break;
                        }

                    }

                    if(isFolder){

                        new File(target +"/"+ file.getName()).mkdirs();
                        generateOriginalFileStructure(file.listFiles(), target + "/"+ file.getName());

                    }


                }

                   else{

                    new File(target +"/"+ file.getName()).mkdirs();
                    generateOriginalFileStructure(file.listFiles(), target + "/"+ file.getName());


                    }
                }





            }


        }

    //returns manifest by property values like timestamp, command, lables in a manifest file.
    //fileLabel may contain label in the manifest file or the path to manifest file!
    private File getManifest(String repoPath, String fileLabel)  throws  FileNotFoundException, IOException  {

        boolean isLabel = false;
        String filename = repoPath + "/" + fileLabel;

        if (repoPath == "")
            filename = fileLabel;
        //check if the fileLabel is path to the manifest file
        File f = new File(filename);

            if(f.exists() && !f.isDirectory()) {


                return f;

            }
            else{
                isLabel = true;

            }



        if (isLabel){

            //get all the manifest files

            File dir = new File(repoPath);
            File [] files = dir.listFiles(new FilenameFilter() {

                @Override
                public boolean accept(File dir, String name) {
                    return name.endsWith(".manifest");
                }
            });


            //check all manifest files to see if we find the label we are searching for

            for( File file : files){


                Scanner fileScanner = new Scanner(file);

                while(fileScanner.hasNextLine()){



                    String line = fileScanner.nextLine();
                    if(line.toUpperCase().startsWith(Config.prpLABEL) ){            //Manfiest with a matching label found

                       String existingLabels = line.split(":",2)[1];

                       if (existingLabels != ""){

                           for(String s:existingLabels.split(";") ){

                                    if (s.toUpperCase().matches(fileLabel.toUpperCase())){
                                        return  file;
                                    }
                           }
                       }
                    }



                }


            }



        }




        return null;   //no label or property found.. complete this to be later treated as an exception that needs handling



    }

    private String getExtension(String fileName){

        String extension = "";

        int i = fileName.lastIndexOf('.');
        if (i >= 0) {
            extension = fileName.substring(i+1);
        }

        return extension;
    }


    private static final void initManifest(String cmd, String user){

        manifestBuilder.append("COMMAND   : "+cmd + System.getProperty("line.separator"));
        manifestBuilder.append("TIMESTAMP : "+ new java.util.Date() + System.getProperty("line.separator"));
        manifestBuilder.append("USER      : "+ user+ System.getProperty("line.separator"));


    }


    private static final void dumpManifest(String _target,String _cmd) throws IOException{


        File file = new File((_target + "/" + _cmd + "_" + (new SimpleDateFormat("yyyyMMdd_HHmmss")).format(Calendar.getInstance().getTime()).hashCode()) + ".manifest");
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(file));
            writer.write(manifestBuilder.toString());
        } finally {
            if (writer != null) writer.close();
        }


    }

    private static final void addFileToManifest(String fileName, String artID,String filePath){

        manifestBuilder.append("FILENAME  : "+fileName + System.getProperty("line.separator"));
        manifestBuilder.append("FILEPATH  : "+filePath + System.getProperty("line.separator"));
        manifestBuilder.append("artID     : "+artID + System.getProperty("line.separator"));


    }



    private static String getCheckSum (String filePath) throws  IOException{


        BufferedReader b1 = null;
        FileReader f1 = null;
        String  s1 = "", s2 = "";

            f1 = new FileReader(filePath);
            b1 = new BufferedReader(f1);
            while ((s1 = b1.readLine()) != null) {
                s2 = s2 + s1;
            }



           return  checkfile(s2);



    }


    private  static String checkfile(String x) {
        //  System.out.println(x);
        //System.out.println(x.length());
        int i, c;
        double sum = 0;
        for (i = 0; i < x.length(); i++) {
            c = x.charAt(i);
            //System.out.println(c);
            if (i % 4 == 0) {
                sum = sum + c * 1;
            } else if (i % 4 == 1) {
                sum = sum + c * 7;
            } else if (i % 4 == 2) {
                sum = sum + c * 11;
            } else if (i % 4 == 3) {
                sum = sum + c * 17;
            }
        }

        if(sum > 2147483647)
            sum=sum%2147483647;

        return String.valueOf(new Double(sum).toString()).split("\\.")[0] + "-L"+ x.length();

    }



}